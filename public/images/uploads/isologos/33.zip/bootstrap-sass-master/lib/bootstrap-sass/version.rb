module Bootstrap
  VERSION = '3.1.1.0'
  BOOTSTRAP_SHA = 'cb3f3926d79935f5b38611c10e7109b380df2c4f'
end
